<?php
$server = 'idamedia.dk.mysql';
$username = 'idamedia_dk';
$password = 'dZVtqYR2';
$database = 'idamedia_dk';


try{
	$conn = new PDO("mysql:host=$server;dbname=$database;", $username, $password);
} catch(PDOException $e){
	die( "Connection failed: " . $e->getMessage());
}


